package day07;
/*
	노래 한곡을 나타내는 Song 클래스를 작성하세요. Song은 다음 필드(변수)로 구성됩니다. 
		- 노래 제목을 나타내는 title
		- 가수를 나타내는 artist
		- 노래가 발표된 연도를 나타내는 year
		- 국적을 나타내는 country
	또한, Song클래스에 다음 생성자와 메서드를 작성하세요. 
		- 생성자 총 2개 : 기본생성자와 매개변수로 모든 필드를 초기화하는 생성자 
		- 노래 정보를 출력하는 show() 메서드 
	그리고 main 메서드에서는 2021년, 한국국적의 이무진이 부른 신호등 을 Song 객체로 생성,
	show() 메서드를 이용하여 정보를 아래와 같이 출력하세요. 
	
	콘솔 출력예 >> 2021년 한국국적의 이무진이 부른 신호등 
*/
class Song {
	
}
public class Test89 {
	public static void main(String[] args) {

		// 작성 필요
		
	}
}
